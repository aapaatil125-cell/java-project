package dao;

import model.Task;
import util.DBConnection;

import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class TaskDAO {

    public boolean addTask(Task t) {
        String sql = "INSERT INTO tasks (project_id, task_name, description, priority, status, due_date) VALUES (?, ?, ?, ?, ?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, t.getProjectId());
            stmt.setString(2, t.getTaskName());
            stmt.setString(3, t.getDescription());
            stmt.setString(4, t.getPriority());
            stmt.setString(5, t.getStatus());
            stmt.setDate(6, t.getDueDate() != null ? Date.valueOf(t.getDueDate()) : null);

            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public List<Task> getAllTasks() {
        List<Task> tasks = new ArrayList<>();
        String sql = "SELECT * FROM tasks";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                Date due = rs.getDate("due_date");
                tasks.add(new Task(
                        rs.getInt("task_id"),
                        rs.getInt("project_id"),
                        rs.getString("task_name"),
                        rs.getString("description"),
                        rs.getString("priority"),
                        rs.getString("status"),
                        due != null ? due.toLocalDate() : null
                ));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return tasks;
    }

    public boolean updateTask(Task t) {
        String sql = "UPDATE tasks SET project_id=?, task_name=?, description=?, priority=?, status=?, due_date=? WHERE task_id=?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, t.getProjectId());
            stmt.setString(2, t.getTaskName());
            stmt.setString(3, t.getDescription());
            stmt.setString(4, t.getPriority());
            stmt.setString(5, t.getStatus());
            stmt.setDate(6, t.getDueDate() != null ? Date.valueOf(t.getDueDate()) : null);
            stmt.setInt(7, t.getTaskId());

            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean deleteTask(int taskId) {
        String sql = "DELETE FROM tasks WHERE task_id=?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, taskId);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}