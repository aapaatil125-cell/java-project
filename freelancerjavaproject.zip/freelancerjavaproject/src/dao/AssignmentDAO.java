package dao;

import util.DBConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class AssignmentDAO {

    public boolean assignFreelancer(int projectId, int freelancerId) {
        String sql = "INSERT INTO project_assignments (project_id, freelancer_id) VALUES (?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, projectId);
            stmt.setInt(2, freelancerId);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean removeAssignment(int assignmentId) {
        String sql = "DELETE FROM project_assignments WHERE assignment_id=?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, assignmentId);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Returns readable assignment rows by joining across 3 tables
    public List<Object[]> getAllAssignmentsDetailed() {
        List<Object[]> result = new ArrayList<>();
        String sql = "SELECT pa.assignment_id, p.project_name, f.full_name, pa.assigned_date " +
                     "FROM project_assignments pa " +
                     "JOIN projects p ON pa.project_id = p.project_id " +
                     "JOIN freelancers f ON pa.freelancer_id = f.freelancer_id";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                result.add(new Object[]{
                        rs.getInt("assignment_id"),
                        rs.getString("project_name"),
                        rs.getString("full_name"),
                        rs.getDate("assigned_date")
                });
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return result;
    }
}