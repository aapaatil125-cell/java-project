package dao;

import model.Freelancer;
import util.DBConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class FreelancerDAO {

    // CREATE — add a new freelancer
    public boolean addFreelancer(Freelancer f) {
        String sql = "INSERT INTO freelancers (full_name, email, phone, skill, hourly_rate) VALUES (?, ?, ?, ?, ?)";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, f.getFullName());
            stmt.setString(2, f.getEmail());
            stmt.setString(3, f.getPhone());
            stmt.setString(4, f.getSkill());
            stmt.setDouble(5, f.getHourlyRate());

            int rowsInserted = stmt.executeUpdate();
            return rowsInserted > 0;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // READ — get all freelancers
    public List<Freelancer> getAllFreelancers() {
        List<Freelancer> freelancers = new ArrayList<>();
        String sql = "SELECT * FROM freelancers";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                Freelancer f = new Freelancer(
                        rs.getInt("freelancer_id"),
                        rs.getString("full_name"),
                        rs.getString("email"),
                        rs.getString("phone"),
                        rs.getString("skill"),
                        rs.getDouble("hourly_rate")
                );
                freelancers.add(f);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return freelancers;
    }

    // UPDATE — modify an existing freelancer
    public boolean updateFreelancer(Freelancer f) {
        String sql = "UPDATE freelancers SET full_name=?, email=?, phone=?, skill=?, hourly_rate=? WHERE freelancer_id=?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, f.getFullName());
            stmt.setString(2, f.getEmail());
            stmt.setString(3, f.getPhone());
            stmt.setString(4, f.getSkill());
            stmt.setDouble(5, f.getHourlyRate());
            stmt.setInt(6, f.getFreelancerId());

            int rowsUpdated = stmt.executeUpdate();
            return rowsUpdated > 0;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // DELETE — remove a freelancer
    public boolean deleteFreelancer(int freelancerId) {
        String sql = "DELETE FROM freelancers WHERE freelancer_id=?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, freelancerId);
            int rowsDeleted = stmt.executeUpdate();
            return rowsDeleted > 0;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}