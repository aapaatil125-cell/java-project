package dao;

import model.Payment;
import util.DBConnection;

import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class PaymentDAO {

    public boolean addPayment(Payment p) {
        String sql = "INSERT INTO payments (project_id, total_budget, amount_paid, payment_date, payment_status) VALUES (?, ?, ?, ?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, p.getProjectId());
            stmt.setDouble(2, p.getTotalBudget());
            stmt.setDouble(3, p.getAmountPaid());
            stmt.setDate(4, p.getPaymentDate() != null ? Date.valueOf(p.getPaymentDate()) : null);
            stmt.setString(5, p.getPaymentStatus());

            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public List<Payment> getAllPayments() {
        List<Payment> payments = new ArrayList<>();
        String sql = "SELECT * FROM payments";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                Date pd = rs.getDate("payment_date");
                payments.add(new Payment(
                        rs.getInt("payment_id"),
                        rs.getInt("project_id"),
                        rs.getDouble("total_budget"),
                        rs.getDouble("amount_paid"),
                        pd != null ? pd.toLocalDate() : null,
                        rs.getString("payment_status")
                ));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return payments;
    }

    public boolean updatePayment(Payment p) {
        String sql = "UPDATE payments SET project_id=?, total_budget=?, amount_paid=?, payment_date=?, payment_status=? WHERE payment_id=?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, p.getProjectId());
            stmt.setDouble(2, p.getTotalBudget());
            stmt.setDouble(3, p.getAmountPaid());
            stmt.setDate(4, p.getPaymentDate() != null ? Date.valueOf(p.getPaymentDate()) : null);
            stmt.setString(5, p.getPaymentStatus());
            stmt.setInt(6, p.getPaymentId());

            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean deletePayment(int paymentId) {
        String sql = "DELETE FROM payments WHERE payment_id=?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, paymentId);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}