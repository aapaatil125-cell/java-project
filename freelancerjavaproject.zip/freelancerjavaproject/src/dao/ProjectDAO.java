package dao;

import model.Project;
import util.DBConnection;

import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class ProjectDAO {

    public boolean addProject(Project p) {
        String sql = "INSERT INTO projects (project_name, client_id, description, budget, start_date, deadline, status) VALUES (?, ?, ?, ?, ?, ?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, p.getProjectName());
            stmt.setInt(2, p.getClientId());
            stmt.setString(3, p.getDescription());
            stmt.setDouble(4, p.getBudget());
            stmt.setDate(5, p.getStartDate() != null ? Date.valueOf(p.getStartDate()) : null);
            stmt.setDate(6, p.getDeadline() != null ? Date.valueOf(p.getDeadline()) : null);
            stmt.setString(7, p.getStatus());

            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public List<Project> getAllProjects() {
        List<Project> projects = new ArrayList<>();
        String sql = "SELECT * FROM projects";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                projects.add(mapRow(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return projects;
    }

    public boolean updateProject(Project p) {
        String sql = "UPDATE projects SET project_name=?, client_id=?, description=?, budget=?, start_date=?, deadline=?, status=? WHERE project_id=?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, p.getProjectName());
            stmt.setInt(2, p.getClientId());
            stmt.setString(3, p.getDescription());
            stmt.setDouble(4, p.getBudget());
            stmt.setDate(5, p.getStartDate() != null ? Date.valueOf(p.getStartDate()) : null);
            stmt.setDate(6, p.getDeadline() != null ? Date.valueOf(p.getDeadline()) : null);
            stmt.setString(7, p.getStatus());
            stmt.setInt(8, p.getProjectId());

            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean deleteProject(int projectId) {
        String sql = "DELETE FROM projects WHERE project_id=?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, projectId);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    private Project mapRow(ResultSet rs) throws SQLException {
        Date start = rs.getDate("start_date");
        Date end = rs.getDate("deadline");
        return new Project(
                rs.getInt("project_id"),
                rs.getString("project_name"),
                rs.getInt("client_id"),
                rs.getString("description"),
                rs.getDouble("budget"),
                start != null ? start.toLocalDate() : null,
                end != null ? end.toLocalDate() : null,
                rs.getString("status")
        );
    }
}