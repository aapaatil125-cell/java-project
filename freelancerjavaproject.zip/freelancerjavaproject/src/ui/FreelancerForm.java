package ui;

import dao.FreelancerDAO;
import model.Freelancer;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class FreelancerForm extends JFrame {

    private JTextField nameField, emailField, phoneField, skillField, rateField;
    private JTable table;
    private DefaultTableModel tableModel;
    private FreelancerDAO dao = new FreelancerDAO();
    private int selectedId = -1;

    public FreelancerForm() {
        setTitle("Manage Freelancers");
        setSize(850, 600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout());
        getContentPane().setBackground(util.UITheme.BACKGROUND);

        // ---- FORM PANEL ----
        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setBackground(util.UITheme.BACKGROUND);
        formPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 8, 8, 8);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        gbc.gridx = 0; gbc.gridy = 0;
        formPanel.add(makeLabel("Full Name:"), gbc);
        gbc.gridx = 1;
        nameField = new JTextField(15);
        util.UITheme.styleTextField(nameField);
        formPanel.add(nameField, gbc);

        gbc.gridx = 2;
        formPanel.add(makeLabel("Email:"), gbc);
        gbc.gridx = 3;
        emailField = new JTextField(15);
        util.UITheme.styleTextField(emailField);
        formPanel.add(emailField, gbc);

        gbc.gridx = 0; gbc.gridy = 1;
        formPanel.add(makeLabel("Phone:"), gbc);
        gbc.gridx = 1;
        phoneField = new JTextField(15);
        util.UITheme.styleTextField(phoneField);
        formPanel.add(phoneField, gbc);

        gbc.gridx = 2;
        formPanel.add(makeLabel("Skill:"), gbc);
        gbc.gridx = 3;
        skillField = new JTextField(15);
        util.UITheme.styleTextField(skillField);
        formPanel.add(skillField, gbc);

        gbc.gridx = 0; gbc.gridy = 2;
        formPanel.add(makeLabel("Hourly Rate:"), gbc);
        gbc.gridx = 1;
        rateField = new JTextField(15);
        util.UITheme.styleTextField(rateField);
        formPanel.add(rateField, gbc);

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 10));
        buttonPanel.setBackground(util.UITheme.BACKGROUND);
        JButton addBtn = new JButton("Add");
        JButton updateBtn = new JButton("Update");
        JButton deleteBtn = new JButton("Delete");
        JButton clearBtn = new JButton("Clear");
        for (JButton b : new JButton[]{addBtn, updateBtn, deleteBtn, clearBtn}) {
            util.UITheme.styleButton(b);
        }
        buttonPanel.add(addBtn);
        buttonPanel.add(updateBtn);
        buttonPanel.add(deleteBtn);
        buttonPanel.add(clearBtn);

        gbc.gridx = 0; gbc.gridy = 3;
        gbc.gridwidth = 4;
        formPanel.add(buttonPanel, gbc);

        add(formPanel, BorderLayout.NORTH);

        // ---- TABLE ----
        tableModel = new DefaultTableModel(
                new String[]{"ID", "Name", "Email", "Phone", "Skill", "Rate"}, 0
        );
        table = new JTable(tableModel);
        util.UITheme.styleTable(table);
        add(new JScrollPane(table), BorderLayout.CENTER);

        // ---- ACTIONS ----
        addBtn.addActionListener(e -> addFreelancer());
        updateBtn.addActionListener(e -> updateFreelancer());
        deleteBtn.addActionListener(e -> deleteFreelancer());
        clearBtn.addActionListener(e -> clearFields());
        table.getSelectionModel().addListSelectionListener(e -> loadSelectedRow());

        loadTableData();
        setVisible(true);
    }

    private JLabel makeLabel(String text) {
        JLabel label = new JLabel(text);
        util.UITheme.styleLabel(label);
        return label;
    }

    private void loadTableData() {
        tableModel.setRowCount(0);
        List<Freelancer> list = dao.getAllFreelancers();
        for (Freelancer f : list) {
            tableModel.addRow(new Object[]{
                    f.getFreelancerId(), f.getFullName(), f.getEmail(),
                    f.getPhone(), f.getSkill(), f.getHourlyRate()
            });
        }
    }

    private void addFreelancer() {
        try {
            Freelancer f = new Freelancer(
                    nameField.getText(),
                    emailField.getText(),
                    phoneField.getText(),
                    skillField.getText(),
                    Double.parseDouble(rateField.getText())
            );
            if (dao.addFreelancer(f)) {
                JOptionPane.showMessageDialog(this, "Freelancer added successfully!");
                loadTableData();
                clearFields();
            } else {
                JOptionPane.showMessageDialog(this, "Failed to add freelancer.");
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Hourly rate must be a number.");
        }
    }

    private void updateFreelancer() {
        if (selectedId == -1) {
            JOptionPane.showMessageDialog(this, "Select a freelancer from the table first.");
            return;
        }
        try {
            Freelancer f = new Freelancer(
                    selectedId,
                    nameField.getText(),
                    emailField.getText(),
                    phoneField.getText(),
                    skillField.getText(),
                    Double.parseDouble(rateField.getText())
            );
            if (dao.updateFreelancer(f)) {
                JOptionPane.showMessageDialog(this, "Freelancer updated!");
                loadTableData();
                clearFields();
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Hourly rate must be a number.");
        }
    }

    private void deleteFreelancer() {
        if (selectedId == -1) {
            JOptionPane.showMessageDialog(this, "Select a freelancer from the table first.");
            return;
        }
        int confirm = JOptionPane.showConfirmDialog(this, "Delete this freelancer?", "Confirm", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            if (dao.deleteFreelancer(selectedId)) {
                JOptionPane.showMessageDialog(this, "Freelancer deleted.");
                loadTableData();
                clearFields();
            }
        }
    }

    private void loadSelectedRow() {
        int row = table.getSelectedRow();
        if (row >= 0) {
            selectedId = (int) tableModel.getValueAt(row, 0);
            nameField.setText(tableModel.getValueAt(row, 1).toString());
            emailField.setText(tableModel.getValueAt(row, 2).toString());
            phoneField.setText(tableModel.getValueAt(row, 3).toString());
            skillField.setText(tableModel.getValueAt(row, 4).toString());
            rateField.setText(tableModel.getValueAt(row, 5).toString());
        }
    }

    private void clearFields() {
        nameField.setText("");
        emailField.setText("");
        phoneField.setText("");
        skillField.setText("");
        rateField.setText("");
        selectedId = -1;
        table.clearSelection();
    }

    public static void main(String[] args) {
        new FreelancerForm();
    }
}