package ui;

import dao.ClientDAO;
import dao.FreelancerDAO;
import dao.PaymentDAO;
import dao.ProjectDAO;
import model.Payment;
import model.Project;

import javax.swing.*;
import java.awt.*;
import java.util.List;

public class Dashboard extends JFrame {

    private JLabel freelancerCountLabel, clientCountLabel, activeCountLabel,
            completedCountLabel, revenueLabel, pendingLabel;

    private FreelancerDAO freelancerDao = new FreelancerDAO();
    private ClientDAO clientDao = new ClientDAO();
    private ProjectDAO projectDao = new ProjectDAO();
    private PaymentDAO paymentDao = new PaymentDAO();

    public Dashboard() {
        setTitle("Freelancer Project Management System - Dashboard");
        setSize(900, 600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        addWindowListener(new java.awt.event.WindowAdapter() {
            @Override
            public void windowClosing(java.awt.event.WindowEvent e) {
                int confirm = JOptionPane.showConfirmDialog(
                        Dashboard.this,
                        "Are you sure you want to exit?",
                        "Confirm Exit",
                        JOptionPane.YES_NO_OPTION
                );
                if (confirm == JOptionPane.YES_OPTION) {
                    System.exit(0);
                }
            }
        });
        setLayout(new BorderLayout());
        getContentPane().setBackground(util.UITheme.BACKGROUND);

        JPanel navPanel = new JPanel();
        navPanel.setBackground(util.UITheme.PRIMARY);
        navPanel.setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));

        JButton dashboardBtn = new JButton("Dashboard");
        JButton freelancersBtn = new JButton("Freelancers");
        JButton clientsBtn = new JButton("Clients");
        JButton projectsBtn = new JButton("Projects");
        JButton tasksBtn = new JButton("Tasks");
        JButton paymentsBtn = new JButton("Payments");
        JButton assignBtn = new JButton("Assignments");
        JButton reportsBtn = new JButton("Reports");
        JButton logoutBtn = new JButton("Logout");

        for (JButton btn : new JButton[]{dashboardBtn, freelancersBtn, clientsBtn, projectsBtn,
                tasksBtn, paymentsBtn, assignBtn, reportsBtn, logoutBtn}) {
            util.UITheme.styleNavButton(btn);
            navPanel.add(btn);
        }
        add(navPanel, BorderLayout.NORTH);

        JPanel cardPanel = new JPanel();
        cardPanel.setLayout(new GridLayout(2, 3, 20, 20));
        cardPanel.setBorder(BorderFactory.createEmptyBorder(30, 30, 30, 30));

        freelancerCountLabel = new JLabel("0");
        clientCountLabel = new JLabel("0");
        activeCountLabel = new JLabel("0");
        completedCountLabel = new JLabel("0");
        revenueLabel = new JLabel("$0");
        pendingLabel = new JLabel("$0");

        cardPanel.add(createCard("Total Freelancers", freelancerCountLabel));
        cardPanel.add(createCard("Total Clients", clientCountLabel));
        cardPanel.add(createCard("Active Projects", activeCountLabel));
        cardPanel.add(createCard("Completed Projects", completedCountLabel));
        cardPanel.add(createCard("Total Revenue", revenueLabel));
        cardPanel.add(createCard("Pending Payments", pendingLabel));

        add(cardPanel, BorderLayout.CENTER);

        // ---- NAVIGATION ACTIONS ----
        freelancersBtn.addActionListener(e -> new FreelancerForm());
        clientsBtn.addActionListener(e -> new ClientForm());
        projectsBtn.addActionListener(e -> new ProjectForm());
        tasksBtn.addActionListener(e -> new TaskForm());
        paymentsBtn.addActionListener(e -> new PaymentForm());
        dashboardBtn.addActionListener(e -> refreshCounts());
        reportsBtn.addActionListener(e -> new ReportsForm());
        assignBtn.addActionListener(e -> new AssignmentForm());
        logoutBtn.addActionListener(e -> {
            dispose();
            new LoginForm();
        });

        refreshCounts();
        setVisible(true);
    }

    private JPanel createCard(String title, JLabel valueLabel) {
        JPanel card = new JPanel();
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
        card.setBackground(util.UITheme.CARD_WHITE);
        card.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(util.UITheme.BORDER, 1),
                BorderFactory.createEmptyBorder(10, 10, 10, 10)
        ));

        valueLabel.setFont(new Font("Segoe UI", Font.BOLD, 30));
        valueLabel.setForeground(util.UITheme.ACCENT);
        valueLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel titleLabel = new JLabel(title);
        titleLabel.setFont(util.UITheme.FONT_LABEL);
        titleLabel.setForeground(util.UITheme.TEXT_DARK);
        titleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        card.add(Box.createVerticalGlue());
        card.add(valueLabel);
        card.add(titleLabel);
        card.add(Box.createVerticalGlue());

        return card;
    }

    private void refreshCounts() {
        freelancerCountLabel.setText(String.valueOf(freelancerDao.getAllFreelancers().size()));
        clientCountLabel.setText(String.valueOf(clientDao.getAllClients().size()));

        List<Project> projects = projectDao.getAllProjects();
        long activeCount = projects.stream().filter(p -> "Active".equals(p.getStatus())).count();
        long completedCount = projects.stream().filter(p -> "Completed".equals(p.getStatus())).count();
        activeCountLabel.setText(String.valueOf(activeCount));
        completedCountLabel.setText(String.valueOf(completedCount));

        List<Payment> payments = paymentDao.getAllPayments();
        double totalRevenue = payments.stream().mapToDouble(Payment::getAmountPaid).sum();
        double totalPending = payments.stream().mapToDouble(Payment::getPendingAmount).sum();
        revenueLabel.setText(String.format("$%.2f", totalRevenue));
        pendingLabel.setText(String.format("$%.2f", totalPending));
    }

    public static void main(String[] args) {
        new Dashboard();
    }
}