package ui;

import dao.AssignmentDAO;
import dao.FreelancerDAO;
import dao.ProjectDAO;
import model.Freelancer;
import model.Project;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class AssignmentForm extends JFrame {

    private JComboBox<Project> projectDropdown;
    private JComboBox<Freelancer> freelancerDropdown;
    private JTable table;
    private DefaultTableModel tableModel;
    private AssignmentDAO assignmentDao = new AssignmentDAO();
    private ProjectDAO projectDao = new ProjectDAO();
    private FreelancerDAO freelancerDao = new FreelancerDAO();

    public AssignmentForm() {
        setTitle("Assign Freelancers to Projects");
        setSize(850, 550);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout());
        getContentPane().setBackground(util.UITheme.BACKGROUND);

        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setBackground(util.UITheme.BACKGROUND);
        formPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 8, 8, 8);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        gbc.gridx = 0; gbc.gridy = 0;
        formPanel.add(makeLabel("Project:"), gbc);
        gbc.gridx = 1;
        projectDropdown = new JComboBox<>();
        formPanel.add(projectDropdown, gbc);

        gbc.gridx = 2;
        formPanel.add(makeLabel("Freelancer:"), gbc);
        gbc.gridx = 3;
        freelancerDropdown = new JComboBox<>();
        formPanel.add(freelancerDropdown, gbc);

        JButton assignBtn = new JButton("Assign");
        JButton removeBtn = new JButton("Remove Selected");
        util.UITheme.styleButton(assignBtn);
        util.UITheme.styleButton(removeBtn);

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 10));
        buttonPanel.setBackground(util.UITheme.BACKGROUND);
        buttonPanel.add(assignBtn);
        buttonPanel.add(removeBtn);

        gbc.gridx = 0; gbc.gridy = 1;
        gbc.gridwidth = 4;
        formPanel.add(buttonPanel, gbc);

        add(formPanel, BorderLayout.NORTH);

        tableModel = new DefaultTableModel(
                new String[]{"Assignment ID", "Project", "Freelancer", "Assigned Date"}, 0
        );
        table = new JTable(tableModel);
        util.UITheme.styleTable(table);
        add(new JScrollPane(table), BorderLayout.CENTER);

        assignBtn.addActionListener(e -> assignFreelancer());
        removeBtn.addActionListener(e -> removeAssignment());

        loadDropdowns();
        loadTableData();
        setVisible(true);
    }

    private JLabel makeLabel(String text) {
        JLabel label = new JLabel(text);
        util.UITheme.styleLabel(label);
        return label;
    }

    private void loadDropdowns() {
        projectDropdown.removeAllItems();
        for (Project p : projectDao.getAllProjects()) {
            projectDropdown.addItem(p);
        }
        freelancerDropdown.removeAllItems();
        for (Freelancer f : freelancerDao.getAllFreelancers()) {
            freelancerDropdown.addItem(f);
        }
    }

    private void loadTableData() {
        tableModel.setRowCount(0);
        List<Object[]> rows = assignmentDao.getAllAssignmentsDetailed();
        for (Object[] row : rows) {
            tableModel.addRow(row);
        }
    }

    private void assignFreelancer() {
        Project p = (Project) projectDropdown.getSelectedItem();
        Freelancer f = (Freelancer) freelancerDropdown.getSelectedItem();

        if (p == null || f == null) {
            JOptionPane.showMessageDialog(this, "Add at least one project and one freelancer first.");
            return;
        }

        if (assignmentDao.assignFreelancer(p.getProjectId(), f.getFreelancerId())) {
            JOptionPane.showMessageDialog(this, "Freelancer assigned successfully!");
            loadTableData();
        } else {
            JOptionPane.showMessageDialog(this, "Assignment failed.");
        }
    }

    private void removeAssignment() {
        int row = table.getSelectedRow();
        if (row == -1) {
            JOptionPane.showMessageDialog(this, "Select an assignment from the table first.");
            return;
        }
        int assignmentId = (int) tableModel.getValueAt(row, 0);
        int confirm = JOptionPane.showConfirmDialog(this, "Remove this assignment?", "Confirm", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            if (assignmentDao.removeAssignment(assignmentId)) {
                JOptionPane.showMessageDialog(this, "Assignment removed.");
                loadTableData();
            }
        }
    }

    public static void main(String[] args) {
        new AssignmentForm();
    }
}