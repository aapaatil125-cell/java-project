package ui;

import dao.ProjectDAO;
import dao.TaskDAO;
import model.Project;
import model.Task;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.time.LocalDate;
import java.util.List;

public class TaskForm extends JFrame {

    private JTextField nameField, dueDateField;
    private JTextArea descArea;
    private JComboBox<Project> projectDropdown;
    private JComboBox<String> priorityDropdown, statusDropdown;
    private JTable table;
    private DefaultTableModel tableModel;
    private TaskDAO taskDao = new TaskDAO();
    private ProjectDAO projectDao = new ProjectDAO();
    private int selectedId = -1;

    public TaskForm() {
        setTitle("Manage Tasks");
        setSize(1000, 650);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout());
        getContentPane().setBackground(util.UITheme.BACKGROUND);

        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setBackground(util.UITheme.BACKGROUND);
        formPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 8, 8, 8);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        gbc.gridx = 0; gbc.gridy = 0;
        formPanel.add(makeLabel("Task Name:"), gbc);
        gbc.gridx = 1;
        nameField = new JTextField(18);
        util.UITheme.styleTextField(nameField);
        formPanel.add(nameField, gbc);

        gbc.gridx = 2;
        formPanel.add(makeLabel("Project:"), gbc);
        gbc.gridx = 3;
        projectDropdown = new JComboBox<>();
        formPanel.add(projectDropdown, gbc);

        gbc.gridx = 0; gbc.gridy = 1;
        formPanel.add(makeLabel("Priority:"), gbc);
        gbc.gridx = 1;
        priorityDropdown = new JComboBox<>(new String[]{"Low", "Medium", "High"});
        formPanel.add(priorityDropdown, gbc);

        gbc.gridx = 2;
        formPanel.add(makeLabel("Status:"), gbc);
        gbc.gridx = 3;
        statusDropdown = new JComboBox<>(new String[]{"Pending", "In Progress", "Completed"});
        formPanel.add(statusDropdown, gbc);

        gbc.gridx = 0; gbc.gridy = 2;
        formPanel.add(makeLabel("Due Date (yyyy-mm-dd):"), gbc);
        gbc.gridx = 1;
        dueDateField = new JTextField(18);
        util.UITheme.styleTextField(dueDateField);
        formPanel.add(dueDateField, gbc);

        gbc.gridx = 0; gbc.gridy = 3;
        formPanel.add(makeLabel("Description:"), gbc);
        gbc.gridx = 1; gbc.gridwidth = 3;
        descArea = new JTextArea(3, 20);
        descArea.setFont(util.UITheme.FONT_LABEL);
        formPanel.add(new JScrollPane(descArea), gbc);
        gbc.gridwidth = 1;

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 10));
        buttonPanel.setBackground(util.UITheme.BACKGROUND);
        JButton addBtn = new JButton("Add");
        JButton updateBtn = new JButton("Update");
        JButton deleteBtn = new JButton("Delete");
        JButton clearBtn = new JButton("Clear");
        for (JButton b : new JButton[]{addBtn, updateBtn, deleteBtn, clearBtn}) {
            util.UITheme.styleButton(b);
        }
        buttonPanel.add(addBtn);
        buttonPanel.add(updateBtn);
        buttonPanel.add(deleteBtn);
        buttonPanel.add(clearBtn);

        gbc.gridx = 0; gbc.gridy = 4;
        gbc.gridwidth = 4;
        formPanel.add(buttonPanel, gbc);

        add(formPanel, BorderLayout.NORTH);

        tableModel = new DefaultTableModel(
                new String[]{"ID", "Task Name", "Project ID", "Priority", "Status", "Due Date"}, 0
        );
        table = new JTable(tableModel);
        util.UITheme.styleTable(table);
        add(new JScrollPane(table), BorderLayout.CENTER);

        addBtn.addActionListener(e -> addTask());
        updateBtn.addActionListener(e -> updateTask());
        deleteBtn.addActionListener(e -> deleteTask());
        clearBtn.addActionListener(e -> clearFields());
        table.getSelectionModel().addListSelectionListener(e -> loadSelectedRow());

        loadProjectDropdown();
        loadTableData();
        setVisible(true);
    }

    private JLabel makeLabel(String text) {
        JLabel label = new JLabel(text);
        util.UITheme.styleLabel(label);
        return label;
    }

    private void loadProjectDropdown() {
        projectDropdown.removeAllItems();
        List<Project> projects = projectDao.getAllProjects();
        for (Project p : projects) {
            projectDropdown.addItem(p);
        }
    }

    private void loadTableData() {
        tableModel.setRowCount(0);
        List<Task> list = taskDao.getAllTasks();
        for (Task t : list) {
            tableModel.addRow(new Object[]{
                    t.getTaskId(), t.getTaskName(), t.getProjectId(),
                    t.getPriority(), t.getStatus(), t.getDueDate()
            });
        }
    }

    private void addTask() {
        try {
            Project selectedProject = (Project) projectDropdown.getSelectedItem();
            if (selectedProject == null) {
                JOptionPane.showMessageDialog(this, "No project available. Add a project first.");
                return;
            }
            Task t = new Task(
                    selectedProject.getProjectId(),
                    nameField.getText(),
                    descArea.getText(),
                    (String) priorityDropdown.getSelectedItem(),
                    (String) statusDropdown.getSelectedItem(),
                    parseDate(dueDateField.getText())
            );
            if (taskDao.addTask(t)) {
                JOptionPane.showMessageDialog(this, "Task added successfully!");
                loadTableData();
                clearFields();
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Date format must be yyyy-mm-dd.");
        }
    }

    private void updateTask() {
        if (selectedId == -1) {
            JOptionPane.showMessageDialog(this, "Select a task from the table first.");
            return;
        }
        try {
            Project selectedProject = (Project) projectDropdown.getSelectedItem();
            Task t = new Task(
                    selectedId,
                    selectedProject.getProjectId(),
                    nameField.getText(),
                    descArea.getText(),
                    (String) priorityDropdown.getSelectedItem(),
                    (String) statusDropdown.getSelectedItem(),
                    parseDate(dueDateField.getText())
            );
            if (taskDao.updateTask(t)) {
                JOptionPane.showMessageDialog(this, "Task updated!");
                loadTableData();
                clearFields();
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Date format must be yyyy-mm-dd.");
        }
    }

    private void deleteTask() {
        if (selectedId == -1) {
            JOptionPane.showMessageDialog(this, "Select a task from the table first.");
            return;
        }
        int confirm = JOptionPane.showConfirmDialog(this, "Delete this task?", "Confirm", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            if (taskDao.deleteTask(selectedId)) {
                JOptionPane.showMessageDialog(this, "Task deleted.");
                loadTableData();
                clearFields();
            }
        }
    }

    private void loadSelectedRow() {
        int row = table.getSelectedRow();
        if (row >= 0) {
            selectedId = (int) tableModel.getValueAt(row, 0);
            nameField.setText(tableModel.getValueAt(row, 1).toString());
            priorityDropdown.setSelectedItem(tableModel.getValueAt(row, 3).toString());
            statusDropdown.setSelectedItem(tableModel.getValueAt(row, 4).toString());
            Object due = tableModel.getValueAt(row, 5);
            dueDateField.setText(due != null ? due.toString() : "");
        }
    }

    private LocalDate parseDate(String text) {
        if (text == null || text.trim().isEmpty()) return null;
        return LocalDate.parse(text.trim());
    }

    private void clearFields() {
        nameField.setText("");
        dueDateField.setText("");
        descArea.setText("");
        selectedId = -1;
        table.clearSelection();
    }

    public static void main(String[] args) {
        new TaskForm();
    }
}