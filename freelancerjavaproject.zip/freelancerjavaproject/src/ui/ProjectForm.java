package ui;

import dao.ClientDAO;
import dao.ProjectDAO;
import model.Client;
import model.Project;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.time.LocalDate;
import java.util.List;

public class ProjectForm extends JFrame {

    private JTextField nameField, budgetField, startField, deadlineField;
    private JTextArea descArea;
    private JComboBox<Client> clientDropdown;
    private JComboBox<String> statusDropdown;
    private JTable table;
    private DefaultTableModel tableModel;
    private ProjectDAO projectDao = new ProjectDAO();
    private ClientDAO clientDao = new ClientDAO();
    private int selectedId = -1;

    public ProjectForm() {
        setTitle("Manage Projects");
        setSize(1000, 650);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout());
        getContentPane().setBackground(util.UITheme.BACKGROUND);

        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setBackground(util.UITheme.BACKGROUND);
        formPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 8, 8, 8);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        gbc.gridx = 0; gbc.gridy = 0;
        formPanel.add(makeLabel("Project Name:"), gbc);
        gbc.gridx = 1;
        nameField = new JTextField(18);
        util.UITheme.styleTextField(nameField);
        formPanel.add(nameField, gbc);

        gbc.gridx = 2;
        formPanel.add(makeLabel("Client:"), gbc);
        gbc.gridx = 3;
        clientDropdown = new JComboBox<>();
        formPanel.add(clientDropdown, gbc);

        gbc.gridx = 0; gbc.gridy = 1;
        formPanel.add(makeLabel("Budget ($):"), gbc);
        gbc.gridx = 1;
        budgetField = new JTextField(18);
        util.UITheme.styleTextField(budgetField);
        formPanel.add(budgetField, gbc);

        gbc.gridx = 2;
        formPanel.add(makeLabel("Status:"), gbc);
        gbc.gridx = 3;
        statusDropdown = new JComboBox<>(new String[]{"Pending", "Active", "Completed", "Cancelled"});
        formPanel.add(statusDropdown, gbc);

        gbc.gridx = 0; gbc.gridy = 2;
        formPanel.add(makeLabel("Start Date (yyyy-mm-dd):"), gbc);
        gbc.gridx = 1;
        startField = new JTextField(18);
        util.UITheme.styleTextField(startField);
        formPanel.add(startField, gbc);

        gbc.gridx = 2;
        formPanel.add(makeLabel("Deadline (yyyy-mm-dd):"), gbc);
        gbc.gridx = 3;
        deadlineField = new JTextField(18);
        util.UITheme.styleTextField(deadlineField);
        formPanel.add(deadlineField, gbc);

        gbc.gridx = 0; gbc.gridy = 3;
        formPanel.add(makeLabel("Description:"), gbc);
        gbc.gridx = 1; gbc.gridwidth = 3;
        descArea = new JTextArea(3, 20);
        descArea.setFont(util.UITheme.FONT_LABEL);
        formPanel.add(new JScrollPane(descArea), gbc);
        gbc.gridwidth = 1;

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 10));
        buttonPanel.setBackground(util.UITheme.BACKGROUND);
        JButton addBtn = new JButton("Add");
        JButton updateBtn = new JButton("Update");
        JButton deleteBtn = new JButton("Delete");
        JButton clearBtn = new JButton("Clear");
        for (JButton b : new JButton[]{addBtn, updateBtn, deleteBtn, clearBtn}) {
            util.UITheme.styleButton(b);
        }
        buttonPanel.add(addBtn);
        buttonPanel.add(updateBtn);
        buttonPanel.add(deleteBtn);
        buttonPanel.add(clearBtn);

        gbc.gridx = 0; gbc.gridy = 4;
        gbc.gridwidth = 4;
        formPanel.add(buttonPanel, gbc);

        add(formPanel, BorderLayout.NORTH);

        tableModel = new DefaultTableModel(
                new String[]{"ID", "Project Name", "Client ID", "Budget", "Start", "Deadline", "Status"}, 0
        );
        table = new JTable(tableModel);
        util.UITheme.styleTable(table);
        add(new JScrollPane(table), BorderLayout.CENTER);

        addBtn.addActionListener(e -> addProject());
        updateBtn.addActionListener(e -> updateProject());
        deleteBtn.addActionListener(e -> deleteProject());
        clearBtn.addActionListener(e -> clearFields());
        table.getSelectionModel().addListSelectionListener(e -> loadSelectedRow());

        loadClientDropdown();
        loadTableData();
        setVisible(true);
    }

    private JLabel makeLabel(String text) {
        JLabel label = new JLabel(text);
        util.UITheme.styleLabel(label);
        return label;
    }

    private void loadClientDropdown() {
        clientDropdown.removeAllItems();
        List<Client> clients = clientDao.getAllClients();
        for (Client c : clients) {
            clientDropdown.addItem(c);
        }
    }

    private void loadTableData() {
        tableModel.setRowCount(0);
        List<Project> list = projectDao.getAllProjects();
        for (Project p : list) {
            tableModel.addRow(new Object[]{
                    p.getProjectId(), p.getProjectName(), p.getClientId(),
                    p.getBudget(), p.getStartDate(), p.getDeadline(), p.getStatus()
            });
        }
    }

    private void addProject() {
        try {
            Client selectedClient = (Client) clientDropdown.getSelectedItem();
            if (selectedClient == null) {
                JOptionPane.showMessageDialog(this, "No client available. Add a client first.");
                return;
            }
            Project p = new Project(
                    nameField.getText(),
                    selectedClient.getClientId(),
                    descArea.getText(),
                    Double.parseDouble(budgetField.getText()),
                    parseDate(startField.getText()),
                    parseDate(deadlineField.getText()),
                    (String) statusDropdown.getSelectedItem()
            );
            if (projectDao.addProject(p)) {
                JOptionPane.showMessageDialog(this, "Project added successfully!");
                loadTableData();
                clearFields();
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Budget must be a number.");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Date format must be yyyy-mm-dd.");
        }
    }

    private void updateProject() {
        if (selectedId == -1) {
            JOptionPane.showMessageDialog(this, "Select a project from the table first.");
            return;
        }
        try {
            Client selectedClient = (Client) clientDropdown.getSelectedItem();
            Project p = new Project(
                    selectedId,
                    nameField.getText(),
                    selectedClient.getClientId(),
                    descArea.getText(),
                    Double.parseDouble(budgetField.getText()),
                    parseDate(startField.getText()),
                    parseDate(deadlineField.getText()),
                    (String) statusDropdown.getSelectedItem()
            );
            if (projectDao.updateProject(p)) {
                JOptionPane.showMessageDialog(this, "Project updated!");
                loadTableData();
                clearFields();
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Budget must be a number.");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Date format must be yyyy-mm-dd.");
        }
    }

    private void deleteProject() {
        if (selectedId == -1) {
            JOptionPane.showMessageDialog(this, "Select a project from the table first.");
            return;
        }
        int confirm = JOptionPane.showConfirmDialog(this, "Delete this project?", "Confirm", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            if (projectDao.deleteProject(selectedId)) {
                JOptionPane.showMessageDialog(this, "Project deleted.");
                loadTableData();
                clearFields();
            }
        }
    }

    private void loadSelectedRow() {
        int row = table.getSelectedRow();
        if (row >= 0) {
            selectedId = (int) tableModel.getValueAt(row, 0);
            nameField.setText(tableModel.getValueAt(row, 1).toString());
            budgetField.setText(tableModel.getValueAt(row, 3).toString());
            Object start = tableModel.getValueAt(row, 4);
            Object end = tableModel.getValueAt(row, 5);
            startField.setText(start != null ? start.toString() : "");
            deadlineField.setText(end != null ? end.toString() : "");
            statusDropdown.setSelectedItem(tableModel.getValueAt(row, 6).toString());
        }
    }

    private LocalDate parseDate(String text) {
        if (text == null || text.trim().isEmpty()) return null;
        return LocalDate.parse(text.trim());
    }

    private void clearFields() {
        nameField.setText("");
        budgetField.setText("");
        startField.setText("");
        deadlineField.setText("");
        descArea.setText("");
        selectedId = -1;
        table.clearSelection();
    }

    public static void main(String[] args) {
        new ProjectForm();
    }
}