package ui;

import dao.*;
import model.*;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class ReportsForm extends JFrame {

    public ReportsForm() {
        setTitle("Reports & Summary");
        setSize(1000, 650);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout());
        getContentPane().setBackground(util.UITheme.BACKGROUND);

        JTabbedPane tabs = new JTabbedPane();
        tabs.setFont(util.UITheme.FONT_BUTTON);
        tabs.addTab("Project Summary", buildProjectReport());
        tabs.addTab("Payment Summary", buildPaymentReport());
        tabs.addTab("Freelancer Summary", buildFreelancerReport());

        add(tabs, BorderLayout.CENTER);
        setVisible(true);
    }

    private JLabel makeSummaryLabel(String text) {
        JLabel label = new JLabel(text);
        label.setFont(util.UITheme.FONT_BUTTON);
        label.setForeground(util.UITheme.PRIMARY);
        label.setBorder(BorderFactory.createEmptyBorder(12, 12, 12, 12));
        label.setOpaque(true);
        label.setBackground(util.UITheme.CARD_WHITE);
        return label;
    }

    private JPanel buildProjectReport() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(util.UITheme.BACKGROUND);
        DefaultTableModel model = new DefaultTableModel(
                new String[]{"Project Name", "Budget", "Status", "Deadline"}, 0
        );
        ProjectDAO dao = new ProjectDAO();
        List<Project> projects = dao.getAllProjects();
        for (Project p : projects) {
            model.addRow(new Object[]{p.getProjectName(), p.getBudget(), p.getStatus(), p.getDeadline()});
        }
        JTable table = new JTable(model);
        util.UITheme.styleTable(table);
        panel.add(new JScrollPane(table), BorderLayout.CENTER);

        long active = projects.stream().filter(p -> "Active".equals(p.getStatus())).count();
        long completed = projects.stream().filter(p -> "Completed".equals(p.getStatus())).count();
        long pending = projects.stream().filter(p -> "Pending".equals(p.getStatus())).count();

        panel.add(makeSummaryLabel(String.format(
                "  Total Projects: %d   |   Active: %d   |   Completed: %d   |   Pending: %d",
                projects.size(), active, completed, pending)), BorderLayout.NORTH);

        return panel;
    }

    private JPanel buildPaymentReport() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(util.UITheme.BACKGROUND);
        DefaultTableModel model = new DefaultTableModel(
                new String[]{"Project ID", "Total Budget", "Paid", "Pending", "Status"}, 0
        );
        PaymentDAO dao = new PaymentDAO();
        List<Payment> payments = dao.getAllPayments();
        double totalRevenue = 0, totalPending = 0;
        for (Payment p : payments) {
            model.addRow(new Object[]{p.getProjectId(), p.getTotalBudget(), p.getAmountPaid(),
                    p.getPendingAmount(), p.getPaymentStatus()});
            totalRevenue += p.getAmountPaid();
            totalPending += p.getPendingAmount();
        }
        JTable table = new JTable(model);
        util.UITheme.styleTable(table);
        panel.add(new JScrollPane(table), BorderLayout.CENTER);

        panel.add(makeSummaryLabel(String.format(
                "  Total Revenue Collected: $%.2f   |   Total Pending: $%.2f", totalRevenue, totalPending)), BorderLayout.NORTH);

        return panel;
    }

    private JPanel buildFreelancerReport() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(util.UITheme.BACKGROUND);
        DefaultTableModel model = new DefaultTableModel(
                new String[]{"Name", "Skill", "Hourly Rate"}, 0
        );
        FreelancerDAO dao = new FreelancerDAO();
        List<Freelancer> freelancers = dao.getAllFreelancers();
        for (Freelancer f : freelancers) {
            model.addRow(new Object[]{f.getFullName(), f.getSkill(), f.getHourlyRate()});
        }
        JTable table = new JTable(model);
        util.UITheme.styleTable(table);
        panel.add(new JScrollPane(table), BorderLayout.CENTER);

        panel.add(makeSummaryLabel("  Total Freelancers: " + freelancers.size()), BorderLayout.NORTH);

        return panel;
    }

    public static void main(String[] args) {
        new ReportsForm();
    }
}