package ui;

import dao.PaymentDAO;
import dao.ProjectDAO;
import model.Payment;
import model.Project;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.time.LocalDate;
import java.util.List;

public class PaymentForm extends JFrame {

    private JTextField budgetField, paidField, dateField;
    private JComboBox<Project> projectDropdown;
    private JTable table;
    private DefaultTableModel tableModel;
    private PaymentDAO paymentDao = new PaymentDAO();
    private ProjectDAO projectDao = new ProjectDAO();
    private int selectedId = -1;

    public PaymentForm() {
        setTitle("Manage Payments");
        setSize(1000, 600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout());
        getContentPane().setBackground(util.UITheme.BACKGROUND);

        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setBackground(util.UITheme.BACKGROUND);
        formPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 8, 8, 8);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        gbc.gridx = 0; gbc.gridy = 0;
        formPanel.add(makeLabel("Project:"), gbc);
        gbc.gridx = 1;
        projectDropdown = new JComboBox<>();
        formPanel.add(projectDropdown, gbc);

        gbc.gridx = 2;
        formPanel.add(makeLabel("Total Budget ($):"), gbc);
        gbc.gridx = 3;
        budgetField = new JTextField(15);
        util.UITheme.styleTextField(budgetField);
        formPanel.add(budgetField, gbc);

        gbc.gridx = 0; gbc.gridy = 1;
        formPanel.add(makeLabel("Amount Paid ($):"), gbc);
        gbc.gridx = 1;
        paidField = new JTextField(15);
        util.UITheme.styleTextField(paidField);
        formPanel.add(paidField, gbc);

        gbc.gridx = 2;
        formPanel.add(makeLabel("Payment Date (yyyy-mm-dd):"), gbc);
        gbc.gridx = 3;
        dateField = new JTextField(15);
        util.UITheme.styleTextField(dateField);
        formPanel.add(dateField, gbc);

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 10));
        buttonPanel.setBackground(util.UITheme.BACKGROUND);
        JButton addBtn = new JButton("Add");
        JButton updateBtn = new JButton("Update");
        JButton deleteBtn = new JButton("Delete");
        JButton clearBtn = new JButton("Clear");
        for (JButton b : new JButton[]{addBtn, updateBtn, deleteBtn, clearBtn}) {
            util.UITheme.styleButton(b);
        }
        buttonPanel.add(addBtn);
        buttonPanel.add(updateBtn);
        buttonPanel.add(deleteBtn);
        buttonPanel.add(clearBtn);

        gbc.gridx = 0; gbc.gridy = 2;
        gbc.gridwidth = 4;
        formPanel.add(buttonPanel, gbc);

        add(formPanel, BorderLayout.NORTH);

        tableModel = new DefaultTableModel(
                new String[]{"ID", "Project ID", "Total Budget", "Paid", "Pending", "Status", "Date"}, 0
        );
        table = new JTable(tableModel);
        util.UITheme.styleTable(table);
        add(new JScrollPane(table), BorderLayout.CENTER);

        addBtn.addActionListener(e -> addPayment());
        updateBtn.addActionListener(e -> updatePayment());
        deleteBtn.addActionListener(e -> deletePayment());
        clearBtn.addActionListener(e -> clearFields());
        table.getSelectionModel().addListSelectionListener(e -> loadSelectedRow());

        loadProjectDropdown();
        loadTableData();
        setVisible(true);
    }

    private JLabel makeLabel(String text) {
        JLabel label = new JLabel(text);
        util.UITheme.styleLabel(label);
        return label;
    }

    private void loadProjectDropdown() {
        projectDropdown.removeAllItems();
        List<Project> projects = projectDao.getAllProjects();
        for (Project p : projects) {
            projectDropdown.addItem(p);
        }
    }

    private void loadTableData() {
        tableModel.setRowCount(0);
        List<Payment> list = paymentDao.getAllPayments();
        for (Payment p : list) {
            tableModel.addRow(new Object[]{
                    p.getPaymentId(), p.getProjectId(), p.getTotalBudget(),
                    p.getAmountPaid(), p.getPendingAmount(), p.getPaymentStatus(), p.getPaymentDate()
            });
        }
    }

    private String calculateStatus(double budget, double paid) {
        if (paid <= 0) return "Unpaid";
        if (paid >= budget) return "Fully Paid";
        return "Partially Paid";
    }

    private void addPayment() {
        try {
            Project selectedProject = (Project) projectDropdown.getSelectedItem();
            if (selectedProject == null) {
                JOptionPane.showMessageDialog(this, "No project available. Add a project first.");
                return;
            }
            double budget = Double.parseDouble(budgetField.getText());
            double paid = Double.parseDouble(paidField.getText());

            Payment p = new Payment(
                    selectedProject.getProjectId(),
                    budget,
                    paid,
                    parseDate(dateField.getText()),
                    calculateStatus(budget, paid)
            );
            if (paymentDao.addPayment(p)) {
                JOptionPane.showMessageDialog(this, "Payment record added!");
                loadTableData();
                clearFields();
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Budget and Paid amount must be numbers.");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Date format must be yyyy-mm-dd.");
        }
    }

    private void updatePayment() {
        if (selectedId == -1) {
            JOptionPane.showMessageDialog(this, "Select a payment from the table first.");
            return;
        }
        try {
            Project selectedProject = (Project) projectDropdown.getSelectedItem();
            double budget = Double.parseDouble(budgetField.getText());
            double paid = Double.parseDouble(paidField.getText());

            Payment p = new Payment(
                    selectedId,
                    selectedProject.getProjectId(),
                    budget,
                    paid,
                    parseDate(dateField.getText()),
                    calculateStatus(budget, paid)
            );
            if (paymentDao.updatePayment(p)) {
                JOptionPane.showMessageDialog(this, "Payment updated!");
                loadTableData();
                clearFields();
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Budget and Paid amount must be numbers.");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Date format must be yyyy-mm-dd.");
        }
    }

    private void deletePayment() {
        if (selectedId == -1) {
            JOptionPane.showMessageDialog(this, "Select a payment from the table first.");
            return;
        }
        int confirm = JOptionPane.showConfirmDialog(this, "Delete this payment record?", "Confirm", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            if (paymentDao.deletePayment(selectedId)) {
                JOptionPane.showMessageDialog(this, "Payment deleted.");
                loadTableData();
                clearFields();
            }
        }
    }

    private void loadSelectedRow() {
        int row = table.getSelectedRow();
        if (row >= 0) {
            selectedId = (int) tableModel.getValueAt(row, 0);
            budgetField.setText(tableModel.getValueAt(row, 2).toString());
            paidField.setText(tableModel.getValueAt(row, 3).toString());
            Object date = tableModel.getValueAt(row, 6);
            dateField.setText(date != null ? date.toString() : "");
        }
    }

    private LocalDate parseDate(String text) {
        if (text == null || text.trim().isEmpty()) return null;
        return LocalDate.parse(text.trim());
    }

    private void clearFields() {
        budgetField.setText("");
        paidField.setText("");
        dateField.setText("");
        selectedId = -1;
        table.clearSelection();
    }

    public static void main(String[] args) {
        new PaymentForm();
    }
}