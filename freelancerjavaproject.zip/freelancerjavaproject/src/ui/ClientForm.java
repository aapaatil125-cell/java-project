package ui;

import dao.ClientDAO;
import model.Client;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class ClientForm extends JFrame {

    private JTextField companyField, contactField, emailField, phoneField, addressField;
    private JTable table;
    private DefaultTableModel tableModel;
    private ClientDAO dao = new ClientDAO();
    private int selectedId = -1;

    public ClientForm() {
        setTitle("Manage Clients");
        setSize(900, 600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout());
        getContentPane().setBackground(util.UITheme.BACKGROUND);

        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setBackground(util.UITheme.BACKGROUND);
        formPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 8, 8, 8);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        gbc.gridx = 0; gbc.gridy = 0;
        formPanel.add(makeLabel("Company Name:"), gbc);
        gbc.gridx = 1;
        companyField = new JTextField(15);
        util.UITheme.styleTextField(companyField);
        formPanel.add(companyField, gbc);

        gbc.gridx = 2;
        formPanel.add(makeLabel("Contact Person:"), gbc);
        gbc.gridx = 3;
        contactField = new JTextField(15);
        util.UITheme.styleTextField(contactField);
        formPanel.add(contactField, gbc);

        gbc.gridx = 0; gbc.gridy = 1;
        formPanel.add(makeLabel("Email:"), gbc);
        gbc.gridx = 1;
        emailField = new JTextField(15);
        util.UITheme.styleTextField(emailField);
        formPanel.add(emailField, gbc);

        gbc.gridx = 2;
        formPanel.add(makeLabel("Phone:"), gbc);
        gbc.gridx = 3;
        phoneField = new JTextField(15);
        util.UITheme.styleTextField(phoneField);
        formPanel.add(phoneField, gbc);

        gbc.gridx = 0; gbc.gridy = 2;
        formPanel.add(makeLabel("Address:"), gbc);
        gbc.gridx = 1; gbc.gridwidth = 3;
        addressField = new JTextField(30);
        util.UITheme.styleTextField(addressField);
        formPanel.add(addressField, gbc);
        gbc.gridwidth = 1;

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 10));
        buttonPanel.setBackground(util.UITheme.BACKGROUND);
        JButton addBtn = new JButton("Add");
        JButton updateBtn = new JButton("Update");
        JButton deleteBtn = new JButton("Delete");
        JButton clearBtn = new JButton("Clear");
        for (JButton b : new JButton[]{addBtn, updateBtn, deleteBtn, clearBtn}) {
            util.UITheme.styleButton(b);
        }
        buttonPanel.add(addBtn);
        buttonPanel.add(updateBtn);
        buttonPanel.add(deleteBtn);
        buttonPanel.add(clearBtn);

        gbc.gridx = 0; gbc.gridy = 3;
        gbc.gridwidth = 4;
        formPanel.add(buttonPanel, gbc);

        add(formPanel, BorderLayout.NORTH);

        tableModel = new DefaultTableModel(
                new String[]{"ID", "Company", "Contact Person", "Email", "Phone", "Address"}, 0
        );
        table = new JTable(tableModel);
        util.UITheme.styleTable(table);
        add(new JScrollPane(table), BorderLayout.CENTER);

        addBtn.addActionListener(e -> addClient());
        updateBtn.addActionListener(e -> updateClient());
        deleteBtn.addActionListener(e -> deleteClient());
        clearBtn.addActionListener(e -> clearFields());
        table.getSelectionModel().addListSelectionListener(e -> loadSelectedRow());

        loadTableData();
        setVisible(true);
    }

    private JLabel makeLabel(String text) {
        JLabel label = new JLabel(text);
        util.UITheme.styleLabel(label);
        return label;
    }

    private void loadTableData() {
        tableModel.setRowCount(0);
        List<Client> list = dao.getAllClients();
        for (Client c : list) {
            tableModel.addRow(new Object[]{
                    c.getClientId(), c.getCompanyName(), c.getContactPerson(),
                    c.getEmail(), c.getPhone(), c.getAddress()
            });
        }
    }

    private void addClient() {
        Client c = new Client(
                companyField.getText(), contactField.getText(),
                emailField.getText(), phoneField.getText(), addressField.getText()
        );
        if (dao.addClient(c)) {
            JOptionPane.showMessageDialog(this, "Client added successfully!");
            loadTableData();
            clearFields();
        } else {
            JOptionPane.showMessageDialog(this, "Failed to add client.");
        }
    }

    private void updateClient() {
        if (selectedId == -1) {
            JOptionPane.showMessageDialog(this, "Select a client from the table first.");
            return;
        }
        Client c = new Client(
                selectedId, companyField.getText(), contactField.getText(),
                emailField.getText(), phoneField.getText(), addressField.getText()
        );
        if (dao.updateClient(c)) {
            JOptionPane.showMessageDialog(this, "Client updated!");
            loadTableData();
            clearFields();
        }
    }

    private void deleteClient() {
        if (selectedId == -1) {
            JOptionPane.showMessageDialog(this, "Select a client from the table first.");
            return;
        }
        int confirm = JOptionPane.showConfirmDialog(this, "Delete this client?", "Confirm", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            if (dao.deleteClient(selectedId)) {
                JOptionPane.showMessageDialog(this, "Client deleted.");
                loadTableData();
                clearFields();
            }
        }
    }

    private void loadSelectedRow() {
        int row = table.getSelectedRow();
        if (row >= 0) {
            selectedId = (int) tableModel.getValueAt(row, 0);
            companyField.setText(tableModel.getValueAt(row, 1).toString());
            contactField.setText(tableModel.getValueAt(row, 2).toString());
            emailField.setText(tableModel.getValueAt(row, 3).toString());
            phoneField.setText(tableModel.getValueAt(row, 4).toString());
            addressField.setText(tableModel.getValueAt(row, 5).toString());
        }
    }

    private void clearFields() {
        companyField.setText("");
        contactField.setText("");
        emailField.setText("");
        phoneField.setText("");
        addressField.setText("");
        selectedId = -1;
        table.clearSelection();
    }

    public static void main(String[] args) {
        new ClientForm();
    }
}