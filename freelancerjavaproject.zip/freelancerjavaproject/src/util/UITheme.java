package util;

import javax.swing.*;
import javax.swing.table.JTableHeader;
import java.awt.*;

public class UITheme {

    // ---- COLOR PALETTE ----
    public static final Color PRIMARY = new Color(41, 50, 65);      // dark navy - nav bars, headers
    public static final Color ACCENT = new Color(52, 152, 219);     // blue - buttons
    public static final Color ACCENT_HOVER = new Color(41, 128, 185);
    public static final Color BACKGROUND = new Color(245, 246, 250); // light gray page background
    public static final Color CARD_WHITE = Color.WHITE;
    public static final Color TEXT_DARK = new Color(33, 37, 41);
    public static final Color BORDER = new Color(222, 226, 230);
    public static final Color ROW_ALT = new Color(240, 244, 248);   // alternating table row

    // ---- FONTS ----
    public static final Font FONT_TITLE = new Font("Segoe UI", Font.BOLD, 22);
    public static final Font FONT_LABEL = new Font("Segoe UI", Font.PLAIN, 14);
    public static final Font FONT_BUTTON = new Font("Segoe UI", Font.BOLD, 13);
    public static final Font FONT_TABLE = new Font("Segoe UI", Font.PLAIN, 13);
    public static final Font FONT_TABLE_HEADER = new Font("Segoe UI", Font.BOLD, 13);

    // ---- STYLING HELPERS ----

    public static void styleButton(JButton button) {
        button.setFont(FONT_BUTTON);
        button.setBackground(ACCENT);
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setBorder(BorderFactory.createEmptyBorder(8, 16, 8, 16));
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
    }

    public static void styleNavButton(JButton button) {
        button.setFont(FONT_BUTTON);
        button.setBackground(PRIMARY);
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setBorder(BorderFactory.createEmptyBorder(10, 14, 10, 14));
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        button.setBorderPainted(false);
    }

    public static void styleTable(JTable table) {
        table.setFont(FONT_TABLE);
        table.setRowHeight(28);
        table.setGridColor(BORDER);
        table.setSelectionBackground(ACCENT);
        table.setSelectionForeground(Color.WHITE);
        table.setShowGrid(true);

        JTableHeader header = table.getTableHeader();
        header.setFont(FONT_TABLE_HEADER);
        header.setBackground(PRIMARY);
        header.setForeground(Color.WHITE);
        header.setPreferredSize(new Dimension(0, 32));
    }

    public static void styleTextField(JTextField field) {
        field.setFont(FONT_LABEL);
        field.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER, 1),
                BorderFactory.createEmptyBorder(6, 8, 6, 8)
        ));
    }

    public static void styleLabel(JLabel label) {
        label.setFont(FONT_LABEL);
        label.setForeground(TEXT_DARK);
    }
}