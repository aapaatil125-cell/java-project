package model;

public class Freelancer {

    private int freelancerId;
    private String fullName;
    private String email;
    private String phone;
    private String skill;
    private double hourlyRate;

    // Constructor for creating a NEW freelancer (no ID yet, database assigns it)
    public Freelancer(String fullName, String email, String phone, String skill, double hourlyRate) {
        this.fullName = fullName;
        this.email = email;
        this.phone = phone;
        this.skill = skill;
        this.hourlyRate = hourlyRate;
    }

    // Constructor for loading an EXISTING freelancer FROM the database (has an ID)
    public Freelancer(int freelancerId, String fullName, String email, String phone, String skill, double hourlyRate) {
        this.freelancerId = freelancerId;
        this.fullName = fullName;
        this.email = email;
        this.phone = phone;
        this.skill = skill;
        this.hourlyRate = hourlyRate;
    }

    // Getters and setters
    public int getFreelancerId() {
        return freelancerId;
    }

    public void setFreelancerId(int freelancerId) {
        this.freelancerId = freelancerId;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getSkill() {
        return skill;
    }

    public void setSkill(String skill) {
        this.skill = skill;
    }

    public double getHourlyRate() {
        return hourlyRate;
    }

    public void setHourlyRate(double hourlyRate) {
        this.hourlyRate = hourlyRate;
    }

    @Override
    public String toString() {
        return fullName + " (" + skill + ") - $" + hourlyRate + "/hr";
    }
}