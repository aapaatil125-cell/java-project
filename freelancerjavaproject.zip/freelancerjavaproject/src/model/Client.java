package model;

public class Client {

    private int clientId;
    private String companyName;
    private String contactPerson;
    private String email;
    private String phone;
    private String address;

    // Constructor for a NEW client (no ID yet)
    public Client(String companyName, String contactPerson, String email, String phone, String address) {
        this.companyName = companyName;
        this.contactPerson = contactPerson;
        this.email = email;
        this.phone = phone;
        this.address = address;
    }

    // Constructor for an EXISTING client (loaded from database, has an ID)
    public Client(int clientId, String companyName, String contactPerson, String email, String phone, String address) {
        this.clientId = clientId;
        this.companyName = companyName;
        this.contactPerson = contactPerson;
        this.email = email;
        this.phone = phone;
        this.address = address;
    }

    public int getClientId() {
        return clientId;
    }

    public void setClientId(int clientId) {
        this.clientId = clientId;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public String getContactPerson() {
        return contactPerson;
    }

    public void setContactPerson(String contactPerson) {
        this.contactPerson = contactPerson;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    @Override
    public String toString() {
        return companyName + " (Contact: " + contactPerson + ")";
    }
}