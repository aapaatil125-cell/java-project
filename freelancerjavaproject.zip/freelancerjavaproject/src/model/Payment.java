package model;

import java.time.LocalDate;

public class Payment {

    private int paymentId;
    private int projectId;
    private double totalBudget;
    private double amountPaid;
    private LocalDate paymentDate;
    private String paymentStatus;

    public Payment(int projectId, double totalBudget, double amountPaid, LocalDate paymentDate, String paymentStatus) {
        this.projectId = projectId;
        this.totalBudget = totalBudget;
        this.amountPaid = amountPaid;
        this.paymentDate = paymentDate;
        this.paymentStatus = paymentStatus;
    }

    public Payment(int paymentId, int projectId, double totalBudget, double amountPaid, LocalDate paymentDate, String paymentStatus) {
        this.paymentId = paymentId;
        this.projectId = projectId;
        this.totalBudget = totalBudget;
        this.amountPaid = amountPaid;
        this.paymentDate = paymentDate;
        this.paymentStatus = paymentStatus;
    }

    public int getPaymentId() { return paymentId; }
    public void setPaymentId(int paymentId) { this.paymentId = paymentId; }

    public int getProjectId() { return projectId; }
    public void setProjectId(int projectId) { this.projectId = projectId; }

    public double getTotalBudget() { return totalBudget; }
    public void setTotalBudget(double totalBudget) { this.totalBudget = totalBudget; }

    public double getAmountPaid() { return amountPaid; }
    public void setAmountPaid(double amountPaid) { this.amountPaid = amountPaid; }

    // Calculated value — not stored directly, remember our database design decision earlier
    public double getPendingAmount() {
        return totalBudget - amountPaid;
    }

    public LocalDate getPaymentDate() { return paymentDate; }
    public void setPaymentDate(LocalDate paymentDate) { this.paymentDate = paymentDate; }

    public String getPaymentStatus() { return paymentStatus; }
    public void setPaymentStatus(String paymentStatus) { this.paymentStatus = paymentStatus; }

    @Override
    public String toString() {
        return "Payment [" + paymentStatus + "] Paid: $" + amountPaid + " / $" + totalBudget;
    }
}