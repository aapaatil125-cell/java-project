package model;

import java.time.LocalDate;

public class Project {

    private int projectId;
    private String projectName;
    private int clientId;
    private String description;
    private double budget;
    private LocalDate startDate;
    private LocalDate deadline;
    private String status;

    // NEW project (no ID yet)
    public Project(String projectName, int clientId, String description, double budget,
                    LocalDate startDate, LocalDate deadline, String status) {
        this.projectName = projectName;
        this.clientId = clientId;
        this.description = description;
        this.budget = budget;
        this.startDate = startDate;
        this.deadline = deadline;
        this.status = status;
    }

    // EXISTING project (loaded from database)
    public Project(int projectId, String projectName, int clientId, String description, double budget,
                    LocalDate startDate, LocalDate deadline, String status) {
        this.projectId = projectId;
        this.projectName = projectName;
        this.clientId = clientId;
        this.description = description;
        this.budget = budget;
        this.startDate = startDate;
        this.deadline = deadline;
        this.status = status;
    }

    public int getProjectId() { return projectId; }
    public void setProjectId(int projectId) { this.projectId = projectId; }

    public String getProjectName() { return projectName; }
    public void setProjectName(String projectName) { this.projectName = projectName; }

    public int getClientId() { return clientId; }
    public void setClientId(int clientId) { this.clientId = clientId; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public double getBudget() { return budget; }
    public void setBudget(double budget) { this.budget = budget; }

    public LocalDate getStartDate() { return startDate; }
    public void setStartDate(LocalDate startDate) { this.startDate = startDate; }

    public LocalDate getDeadline() { return deadline; }
    public void setDeadline(LocalDate deadline) { this.deadline = deadline; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    @Override
    public String toString() {
        return projectName + " [" + status + "] - Budget: $" + budget;
    }
}